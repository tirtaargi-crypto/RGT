package com.reygameturbo.rgt

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var shizukuStatus: TextView
    private var selectedPackage: String? = null
    private val REQUEST = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        shizukuStatus = findViewById(R.id.shizukuStatus)

        findViewById<Button>(R.id.addGame).setOnClickListener { chooseGame() }
        findViewById<Button>(R.id.launchGame).setOnClickListener { launchSelected() }
        findViewById<Button>(R.id.turbo).setOnClickListener { runTurbo() }
        findViewById<Button>(R.id.smooth).setOnClickListener { runSmooth() }
        findViewById<Button>(R.id.clean).setOnClickListener { memoryCleanup() }
        findViewById<Button>(R.id.crosshair).setOnClickListener { openCrosshair() }
        findViewById<Button>(R.id.sidebar).setOnClickListener { openSidebar() }

        updateShizuku()
    }

    override fun onResume() {
        super.onResume()
        updateShizuku()
    }

    private fun updateShizuku() {
        val running = Shizuku.pingBinder()
        if (!running) {
            shizukuStatus.text = "SHIZUKU NOT RUNNING"
            shizukuStatus.setTextColor(Color.rgb(255, 95, 95))
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            shizukuStatus.text = "SHIZUKU NOT PERMISSION"
            shizukuStatus.setTextColor(Color.rgb(255, 190, 70))
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                // status only; user can grant from Shizuku
            }
            return
        }
        shizukuStatus.text = "SHIZUKU READY"
        shizukuStatus.setTextColor(Color.rgb(57, 229, 140))
    }

    private fun hasShizuku(): Boolean {
        if (!Shizuku.pingBinder()) {
            toast("Shizuku not running")
            return false
        }
        if (Build.VERSION.SDK_INT >= 23 &&
            Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(REQUEST)
            toast("Grant ReyGameTurbo permission in Shizuku")
            return false
        }
        return true
    }

    private fun sh(command: String): String {
        if (!hasShizuku()) return "Shizuku unavailable"
        return try {
            val p = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            if (err.isNotBlank()) "$out\n$err".trim() else out.trim()
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    private fun runTurbo() {
        val commands = listOf(
            "settings put system peak_refresh_rate 120.0",
            "settings put system min_refresh_rate 120.0",
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5"
        )
        val result = commands.joinToString("\n") { "$it -> ${sh(it)}" }
        status.text = "TURBO RESULT\n$result"
    }

    private fun runSmooth() {
        val result = sh("settings put system pointer_speed 7")
        status.text = "SMOOTH PROFILE\npointer_speed -> $result\n\nNote: Android does not expose a universal X/Y touch-sampling slider. Vendor-specific parameters are only applied when explicitly supported."
    }

    private fun memoryCleanup() {
        if (!hasShizuku()) return
        val pkg = selectedPackage
        if (pkg == null) {
            status.text = "MEMORY CLEANUP\nSelect a game/app first."
            return
        }
        val result = sh("am force-stop $pkg")
        status.text = "MEMORY CLEANUP\n$pkg\n$result"
    }

    private fun chooseGame() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        val names = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select game / app")
            .setItems(names) { _, which ->
                selectedPackage = apps[which].packageName
                findViewById<TextView>(R.id.selectedGame).text =
                    "${names[which]}  •  $selectedPackage"
            }.show()
    }

    private fun launchSelected() {
        val pkg = selectedPackage ?: run {
            toast("Select a game first")
            return
        }
        startActivity(packageManager.getLaunchIntentForPackage(pkg))
    }

    private fun openCrosshair() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, TurboOverlayService::class.java).apply {
            putExtra("mode", "crosshair")
        })
        status.text = "CROSSHAIR\nOverlay started. Use the sidebar to hide it."
    }

    private fun openSidebar() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, TurboOverlayService::class.java).apply {
            putExtra("mode", "sidebar")
        })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
